#include <iostream>
#include "ode.hpp"
#include <cmath>

using namespace std;

ode::ode(double tini, double xini, double tend, double (*f) (double, double)){
    t_ini=tini;
    x_0=xini;
    t_end=tend;
    sfn=f;
}

double* ode::euler(int n) const{
    double deltat=t_end/n;
    double *t;
    t= new double[n+1];
    t[0]=t_ini;
    for (int k=0;k<n-1;++k){
        t[k+1]=t[k]+deltat;
    }
    t[n]=t_end;
    double *x;
    x= new double[n+1];
    x[0]=x_0;
    for (int i=0;i<n;++i){
        x[i+1]=x[i]+deltat*sfn(t[i],x[i]);
    }
    double *v;
    v= new double[n];
    for (int j=0;j<=n-1;++j){
        v[j]=x[j+1];
    }
return v;
}