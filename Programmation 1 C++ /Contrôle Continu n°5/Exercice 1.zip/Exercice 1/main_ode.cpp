#include "ode.hpp"
#include <cmath>
#include <iostream>

using namespace std;

double f(double t, double x) {
  return x*(1 - exp(t))/(1 + exp(t));
}

int main()
{

  ode exmp(0., 3., 2., f); // x(O) = 3, T =2
  double* soln =exmp.euler(100); // 100 subintervals

  cout << "La valeur approchée de x a l'instant T est: "<< soln[99] << endl;
}

// Commande de compilation
// g++ main_ode.cpp ode.cpp -o main_ode
// ./main_ode