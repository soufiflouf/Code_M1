#include "symmetric.hpp"
#include <iostream>
#include <cmath>

SymmetricMtx::SymmetricMtx(int n, double value){
    n_size = n;
    values = new double[n*(n+1)/2];
    for (int ii = 0; ii<n*(n+1)/2; ii++){
            values[ii] = value;
    }
}

double& SymmetricMtx::operator()(int i, int j) const{
if (i < j){
    return values[j*(j+1)/2+i];
} else {
    return values[i*(i+1)/2+j];
}
}