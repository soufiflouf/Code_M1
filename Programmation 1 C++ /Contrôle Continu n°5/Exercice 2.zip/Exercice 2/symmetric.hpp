#pragma once

class SymmetricMtx{
public:

SymmetricMtx(int n, double value = 0.);

double& operator()(int i, int j) const;

int nsize() const{return n_size;}

private:

int n_size;

double* values;
};