#include <iostream>
#include <cmath>
#include "full.hpp"
#include "symmetric.hpp"

template <typename T>
T sum(T A, T B) {
    T result;
    for (j=0,j<A.nsize;++j){
        for (k=)0;k<B.nsize;++k){
            result[j][k]=A[j][k]+B[j][k];
        }
    }
}